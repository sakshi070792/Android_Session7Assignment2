package com.mani.session7ass2;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    AutoCompleteTextView actv;
    DbHelper dbhelper;
    SQLiteDatabase db;
    String prod[];

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        actv = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView1);
        dbhelper=new DbHelper(this);
        getDataFromDB();


    }
    public void getDataFromDB(){
        db=dbhelper.getReadableDatabase();
        Cursor mcursor=db.rawQuery("Select * from products",null);
        List<String> array = new ArrayList<String>();
        while(mcursor.moveToNext()){
            String uname = mcursor.getString(mcursor.getColumnIndex("product"));
            array.add(uname);


        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,array);
        actv.setAdapter(adapter);


    }
}
