package com.mani.session7ass2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by sakshi.banger on 16-09-2016.
 */
public class DbHelper extends SQLiteOpenHelper {
    SQLiteDatabase db=null;
    public DbHelper(Context context) {
        super(context,"SakshiDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table products(product Text)");
      db.execSQL("insert into products Values('inkjetprinter')");
        db.execSQL("insert into products Values('amazonprinter')");
        db.execSQL("insert into products Values('laserprinter')");
        db.execSQL("insert into products Values('partyprinter')");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


}
